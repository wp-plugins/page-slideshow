=== Page slideshow ===
Contributors: adriankremer
Tags: slideshow,per page,flexslider
Donate link: http://www.proseed.de
Requires at least: 4.0
Tested up to: 4.2.2
License: GPLv2
License URI: http://www.gnu.org/licenses/old-licenses/gpl-2.0

sortable, page based slideshow.

== Description ==
a slideshow plugin that appends to every page. choose images in wordpress style. sortable. it also supports text/headlines.

== Installation ==
Dependencies: jQuery && jQuery.ui (just sortables)

== Screenshots ==
1. this shows the main funcionality. add images, apply a text, and sort if you want.